1.为了做SEO优化
2.为了更快速页面加载时间

采用了 vue SSR服务器端渲染

npm run build:client --> 打包前端代码

npm run build:server --> 前端项目在服务器端打包（node.js）

两个入口： 
entry-client.js 客户端入口主js
entry-server.js 服务器端入口主js

同构（保证自己编写的代码，在不同环境下都可以执行）

node.js 渲染vue项目，只会执行组件的
beforeCreate
created
也就是说我们可以在其他生命周期中 绑定dom操作，使用浏览器API

可以使用node.js创建服务器  ==》 server.js

打包流程：
npm run build 初始化打包
npm run start 启动服务器

