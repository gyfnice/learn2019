<template>
  <div id="app">
    <header class="s-header">
        <nav class="s-navbar">
          <div class="s-navbar-left pull-left">
            <a href="../page/index.html">
              <img src="@/assets/img/home_pic_navlogo.png" class="logo">
            </a>
          </div>
          <div class="s-navbar-right pull-right">
            <ul class="nav-list">
              <li>
                <a href="../page/index.html" class="return-index">赛领首页</a>
              </li>
            </ul>
          </div>
        </nav>
    </header>
    <router-view/>
  </div>
</template>
<style>
  *{
      margin: 0;
      padding: 0;
  }
  body{
      color: #333;
      font-size: 16px;
      font-family: Microsoft Yahei,Arial,STHeiti,sans-serif;
  }
  a{
      color: #333;
      text-decoration: none;
  }
  li{
      list-style: none;
  }
</style>
<style lang="less">
  
</style>
