     //接口管理中心
import axios from "axios";

const devMode = false; //一键切换开发环境 用户名： admin  111111

//所有请求路径的地址
const router = {
  Region: {
    findAllRegions: 'Region/findAllRegions'
  },
  houseSailWebsite: {
    listRegion: 'houseSailWebsite/listRegion',
    layoutDetail:"houseSailWebsite/layoutDetail",
    listLayout: "houseSailWebsite/listLayout"
  },
  contentSailWebsite: {
    detail: 'contentSailWebsite/detail',
    topList: 'contentSailWebsite/topList',
    allAndDiffList: 'contentSailWebsite/allAndDiffList'
  },
  wellCustomer: {
    insert: 'wellCustomer/insert'
  },
  dictionary: {
    selectByPCode: "dictionary/selectByPCode", //获取公寓形式/付款方式下拉列表
  },
};

let webroot = "";
let onceFlag = false;
function interceptorsMethod(store, context) {
  //全局Ajax监控
  axios.interceptors.response.use(
    response => {
      if (response.data.code !== 10000) {
        if ((response.data.code === "20007" || response.data.code === 20007) && !onceFlag) {
          onceFlag = true;
          setTimeout(() => {
            onceFlag = false
          }, 5000)
          context.$modal.info({
            maskClosable: false,
            title: "系统提示",
            content: "请重新登录",
            onOk: function() {
              location.href = "#/login";
            }
          });
          return response;
          //context.$notify({ group: 'auth', title: '请重新登录',  type: 'error', text: '登录权限过期' })
        }
        context.$message.error(response.data.msg);
        setTimeout(() => {
          context.$message.destroy();
        }, 1000)
        return response;
        //store.dispatch('displayErrorLoad');
        //store.commit('updateLoadText', response.data.msg)
        //return;
      }
      if (devMode) {
        return new Promise((resolve, reject) => {
          setTimeout(() => {
            resolve(response);
          }, 0);
        });
      }
      return response;
    },
    error => {
      //store.dispatch('displayErrorLoad');
      store.commit("UPDATE_LOADING_STATUS", false);

      context.$message.error("服务器报错");
      setTimeout(() => {
        context.$message.destroy();
      }, 1000)
      console.log("error");
      console.log(error.response);
      Promise.resolve(error.response);
    }
  );

  axios.interceptors.request.use(
    request => {
      //console.log('---0---');
      //store.commit('UPDATE_LOADING_STATUS', {isLoading: true})
      return request;
    },
    error => {
      //store.dispatch('displayErrorLoad');
      console.log(error);
      Promise.reject(error);
    }
  );
}

function requestMethod(method, uri, data = null) {
  if (!method) {
    console.error("API function call requires method argument");
    return;
  }

  if (!uri) {
    console.error("API function call requires uri argument");
    return;
  }
  if (devMode) {
    //判断开发模式
    method = "get";
    let url = uri;

    return new Promise((resolve, reject) => {
      setTimeout(() => {
        axios({
          method,
          url,
          data,
          timeout: 5000
        }).then(res => {
          resolve(res);
        });
      }, 500);
    });
  }
  var url = uri;
  if (method === "get") {
    return axios.get(url, {
      params: data,
      timeout: 200000
    });
  }
  return axios({ method, url, data, timeout: 10000 });
}
// let pathHoust = "http://c.sailapartment.com"
// let pathURI = "http://c.sailapartment.com"

let apiURL = 'http://manage.sailapartment.com/'
//let pathURI = "http://47.93.117.57/sail-web"
let pathHoust = "http://47.93.117.57"
let pathURI = "http://manage.sailapartment.com"
//if(location.host.indexOf('127.0.0.1') > -1 || location.host.indexOf('192.168.31.202') > -1 || location.host.indexOf('gyf') > -1 || location.host.indexOf('localhost') > -1) {
//    pathHoust = "http://192.168.31.202:8080"
//    pathURI = "http://192.168.31.202:8080/sail-web"
//    apiURL = '/sail-web/' 
//    //pathURI = "http://192.168.31.202:8080"
//}
//if(location.host.indexOf('139.159.190.0') > -1) {
//   pathHoust = "139.159.190.0:8080"
//   pathURI = "139.159.190.0:8080/sail-web"
//   apiURL = 'http://139.159.190.0:8080/sail-web/' 
//}
export default {
  apiURL: apiURL,
  serverHost: pathHoust,
  serverURI: pathURI,
  getURL: url => {
    url = url.replace(/^\//, "");
    const [path, subPath] = url.match(/\w+/g);
    if (devMode) {
      webroot = "/test/";
      let devPath = url.replace(/\//g, "");
      return webroot + devPath + ".json";
    }
    //请求路径
    return apiURL + router[path][subPath];
    //return 'http://47.93.117.57:8081/' + router[path][subPath];
  },
  interceptorsMethod: interceptorsMethod,
  request: requestMethod
};
