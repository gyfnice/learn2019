<template>
   <v-modal class="add-house" :confirm-loading="spinning" title="" :visible="visible" @ok="handleOk" @cancel="handleCancel" :width='900' :mask-closable="false">
   		<template v-if="true" slot="footer">
   		  <span></span>
   		</template>
		 <div class="container_header">
		   <div class="spec-header">
		     <p class="header_title">
		       <img class="header_img" src="@/assets/img/1.png" alt="">
		     </p>
		     <p class="header_words">预约看房</p>
		   </div>
		   <div class="tips">
		     <p class="tips__icon">
		       <img src="@/assets/img/提示.png" alt="">
		     </p>
		    <p class="tips_says">提示 请认真填写您的真实信息，以便我们的服务人员尽快与您取得联系</p>
		  </div>
		   <div class="right"></div>
		 </div>
   		<v-form direction='horizontal' :rules='rules' :model='formModel' ref='formModel'>
  	 	 		<v-row>
  	 	 		  <v-col span='12'>
  	 	 		    <v-form-item label="姓名" prop="name" :label-col="labelCol" :wrapper-col="wrapperCol">
  	 	 		      <v-input size="large" v-model='formModel.name'></v-input>
  	 	 		    </v-form-item>
  	 	 		  </v-col>
  	 	 		  <v-col span='12'>
  	 	 		    <v-form-item label="性别" prop="sex" :label-col="labelCol" :wrapper-col="wrapperCol" >
  	 	 		      <v-radio-group  v-model='formModel.sex' :data="[{value: 'male', text: '男'},{value: 'female', text: '女'}]"></v-radio-group>
  	 	 		    </v-form-item>
  	 	 		  </v-col>
  	 	 		</v-row>
  	 	 		<v-row>
 		          <v-col span='12'>
 		            <v-form-item label="年龄" prop="age" :label-col="labelCol" :wrapper-col="wrapperCol">
 		              <v-select size="lg" v-model="formModel.age"  :data="ageSegmentOptions"></v-select>
 		            </v-form-item>
 		          </v-col>
 		          <v-col span='12'>
 		            <v-form-item label='联系方式' prop="phone" :label-col="labelCol" :wrapper-col="wrapperCol">
              			<v-input size="large" v-model='formModel.phone'></v-input>
 		            </v-form-item>
 		          </v-col>
 		        </v-row>
 		        <v-row>
 		          <v-col span='12'>
 		            <v-form-item label="职业" prop="occupation" :label-col="labelCol" :wrapper-col="wrapperCol">
 		              <v-select size="lg" v-model="formModel.occupation" :data="Occupation"></v-select>
 		            </v-form-item>
 		          </v-col>
 		          <v-col span='12'>
 		            <v-form-item prop="customerType" label='客源属性' :label-col="labelCol" :wrapper-col="wrapperCol">
 		              <v-radio-group  v-model='formModel.customerType' :data="[{value: 1, text: '个人'},{value: 2, text: '企业'}]"></v-radio-group>
 		            </v-form-item>
 		          </v-col>
 		        </v-row>
            <v-row>
              <v-col span='18'>
                <v-form-item label="人员类型" prop="userType" :label-col="{
                  span: 4
                }" :wrapper-col="{
                  span: 18
                }">
                  <v-radio-group  v-model='formModel.userType' :data="[{value: 'usr_type_loney', text: '单身'},{value: 'usr_type_frd', text: '朋友'},{value: 'usr_type_fml', text: '家庭'},{value: 'usr_type_chrd', text: '家庭带小孩'}, {value: 'usr_type_oth', text: '其他'}]"></v-radio-group>
                </v-form-item>
              </v-col>
            </v-row>
            <v-row>
              <v-col span="12">
                <v-form-item prop="subscribeRegion" label='看房项目' :label-col="labelCol" :wrapper-col="wrapperCol">
                  <v-select ref='subHouse' @change="subscribeRegionChange" v-model="formModel.subscribeRegion" :data="remoteProject"></v-select>
                </v-form-item>
              </v-col>
              <v-col span='12'>
                <v-form-item label='预约时间' prop='subscribeTime' :label-col="labelCol" :wrapper-col="wrapperCol">
                  <v-date-picker @change="subscribeTimeChange" style="display: inline-block;width: 150px" v-model="formModel.seeTime" ></v-date-picker>
                  <v-select @change="subscribeTimeChange" style="display: inline-block;width: 100px" placeholder="预约时间段" v-model="formModel.seeTimeInterval" :data="seeTimeIntervalOptions"></v-select>
                  <!-- <v-input v-show="false" v-model="formModel.subscribeTime"></v-input> -->
                </v-form-item>
              </v-col>
            </v-row>
            <v-row>
              <v-col span='12'>
                <v-form-item  label='意向项目' :label-col="labelCol" prop="potentialProjectListSelected" :wrapper-col="wrapperCol">
                  <v-select v-model="formModel.potentialProjectListSelected" @change="addProjects"  search multiple :data='remoteProject' ></v-select>
                </v-form-item>
              </v-col>
              <v-col span='12'>
                <v-form-item label='意向户型' :label-col="labelCol" prop="potentialLayoutListSelected" :wrapper-col="wrapperCol">
                  <v-select v-model="formModel.potentialLayoutListSelected" @change="addLayouts" search multiple  :data='LayoutIntent'></v-select>
                </v-form-item>
              </v-col>
            </v-row>
            <v-row>
              <v-col span='12'>
                <v-form-item label="需求状态" prop='needStatus' :label-col="labelCol" :wrapper-col="wrapperCol">
                  <v-select :data='CustomerState' v-model="formModel.needStatus"></v-select>
                </v-form-item>
              </v-col>
              <v-col span='12'>
                <v-form-item label='计划租期'  prop="planLiveTime" :label-col="labelCol" :wrapper-col="wrapperCol">
                  <v-input-number size='large' v-model='formModel.planLiveTime' ></v-input-number><span>月</span>
                </v-form-item>
              </v-col>
            </v-row>
            <v-row>
              <v-col span="24">
                <v-form-item label='意向价格' prop="price" :label-col="{span:3}" :wrapper-col="{span:18}">
                  <v-radio-group v-model='formModel.price' :data="[{value: '1000', text: '1000元以下/月'},{value: '1000-1500', text: '1000-1500元/月'},{value: '1500-2000', text: '1500-2000元/月'},{value: '2000元以上', text: '2000元以上/月'}]"></v-radio-group>
                </v-form-item>
              </v-col>
            </v-row>
            <v-row>
              <v-col span='24'>
                <v-form-item label="备注" :label-col="{span:3}" :wrapper-col="{span:20}">
                  <v-input type="textarea" size="large" v-model="formModel.remark"></v-input>
                </v-form-item>
              </v-col>
            </v-row>
  	 	</v-form>
  	 	<div class="footer_btn">
  	 	  <v-button-group size="large">
  	 	      <v-button style='color: #000'  @click="handleCancel">取消</v-button>
  	 	      <v-button :loading="loading"  type="primary" @click='handleOk'>确定</v-button>
  	 	  </v-button-group>
  	 	</div>
  	</v-modal>
</template>

<script>
  // @ is an alias to /src
//import HelloWorld from '@/components/HelloWorld.vue'
import { mapState } from "vuex";

import {
  checkTextLength,
  checkPhone,
  checkNumber
} from "@/utils/valid_rule";
export default {
  name: 'addHouse',
  props: ["visible"],
  watch: {
    visible(newval) {
      if(newval) {
        this.remoteProjectMethod("");
        this.$store.dispatch("fetchSelectHouseType", "SourceUser");
        this.$store.dispatch("fetchSelectHouseType", "CustomerState");
        this.$store.dispatch("fetchSelectHouseType", "LayoutIntent");
        this.$store.dispatch("fetchSelectHouseType", "Occupation");
      }
    }
  },
  methods: {
  	handleCancel() {
      this.clearData();
  		this.$emit('hide')
  	},
    clearData() {
      this.formModel = {
            cardCode: "",
            cardType: "",
            //channel: "SourceUser_Official_website",
            channel: "",
            customerType: 1,
            housekeeper: 0,
            id: 0,
            layoutId: 0,
            marryStatus: 0,
            name: "",
            phone: "",
            age: "",
            occupation: "",
            subscribeRegion: "",
            subscribeTime: "",
            seeTime: "",
            seeTimeInterval: 1,

            needStatus: "",
            housekeeperPhone: "",
            planLiveTime: 6,
            userType: 'usr_type_loney',
            price: "1000",
            platform: 4,
            registTime: "",
            remark: "",
            reserveMsg: "",
            seeTime: "",
            sex: "male",
            status: 1,
            wellCoustProps: [],
            potentialProjectListSelected: [],
            potentialLayoutListSelected: []
          }
    },
    handleOk(){
      //this.$message.success('预约成功')
      this.$refs['formModel'].validate((valid) => {
        if (valid) {
            //alert('submit!');
            this.loading = true;
            this.formModel.wellCoustProps = [
              ...this.potentialProjectList,
              ...this.potentialLayoutList,
              ...this.subscribeProjectList
            ];
            
            this.$store.dispatch('addItem', this.formModel).then(res => {
              this.loading = false;
              this.clearData();
              this.$emit('hide')
              setTimeout(() => {
                this.$message.success('预约成功')
              }, 100)
            })
        } else {
            console.log('error submit!!');
            return false;
        }
      });
    },
    addProjects(projectList) {
      this.potentialProjectList = [];
      projectList.map(item => {
        let selectedP = this.remoteProject.filter(p => {
          if (p.value == item) {
            return p;
          }
        });
        let prop = {
          createTime: "",
          createrId: 0,
          createrName: "",
          id: 0,
          propCode: "region",
          propName: selectedP[0].label,
          propValue: selectedP[0].value,
          propValueDesc: "",
          propValueInt: 0,
          wellId: 0
        };
        this.potentialProjectList.push(prop);
      });
      console.log(this.potentialProjectList)
       //console.log("potential Project:", this.potentialProjectList);
     },
     addLayouts(layoutList) {
       this.potentialLayoutList = [];
       layoutList.map(item => {
         let selectedP = this.LayoutIntent.filter(p => {
           if (p.value == item) {
             return p;
           }
         });
         let prop = {
           createTime: "",
           createrId: 0,
           createrName: "",
           id: 0,
           propCode: "layout",
           propName: selectedP[0].label,
           propValue: selectedP[0].value,
           propValueDesc: "",
           propValueInt: 0,
           wellId: 0
         };
         this.potentialLayoutList.push(prop);
       });
       //console.log("potential layout:", this.potentialLayoutList);
     },
     remoteProjectMethod() {
      this.houseLoading = true;
      //this.$store.commit("regionChangeKeyword", query);
      this.$store
        .dispatch("regionFetchRegionList", {
          currentPage: 1,
          pageSize: 1000
        })
        .then(res => {
          this.houseLoading = false;
        });
    },
    subscribeRegionChange(item) {
      //console.log(' this.formModel.subscribeRegion',  this.formModel.subscribeRegion)
      setTimeout(() => {
        this.subscribeProjectList = [{
           "createTime": "",
           "createrId": 0,
           "createrName": "",
           "id": 0,
           "propCode": "book_region",
           "propName": this.$refs.subHouse.$el.innerText,
           "propValue": this.formModel.subscribeRegion,
           "propValueDesc": "预约项目",
           "propValueInt": this.formModel.subscribeRegion,
           "wellId": 0,
        }]
        console.log(this.subscribeProjectList)
      }, 10)
      //console.log('this.formModel.wellCoustProps', this.formModel.wellCoustProps)
    },
    subscribeTimeChange() {
        //console.log('--------------nice=--')
      //this.formModel.subscribeTime = true
      if(this.formModel.seeTime && this.formModel.seeTimeInterval) {
        this.formModel.subscribeTime = true
      }else {
        this.formModel.subscribeTime = ""
      }
    }
  },
  mounted() {
    //this.$store.dispatch("fetchHouseKeeperList");
  },
  computed: {
    ...mapState({
      remoteProject: state => state.regionList,
      //remoteProject: state => state.intentCustomerModule.potentialProjectList,
      SourceUser: state => state.SourceUser,
      //formModel: state => state.intentCustomerModule.formModel,
      LayoutIntent: state => state.LayoutIntent,
      CustomerState: state => state.CustomerState,
      Occupation: state => state.Occupation,
      // houseKeeperList: state => state.intentCustomerModule.houseKeeperList,
      // preLayoutList2: state => state.intentCustomerModule.preLayout,
      // preRegionList2: state => state.intentCustomerModule.preRegion
    })
  },
  data: () => ({
    loading: false,
    spinning: false,
    keeperPhone: "",
    rentVisibal: false,
    selectedRegion: "",
    houseLoading: false,
    labelCol: {
      span: 6
    },
    wrapperCol: {
      span: 16
    },
    seeTimeIntervalOptions: [
      { value: 1, label: "上午" },
      { value: 2, label: "下午" }
    ],
    ageSegmentOptions: [
      { value: "00", label: "00后" },
      { value: "95", label: "95后" },
      { value: "90", label: "90后" },
      { value: "85", label: "85后" },
      { value: "80", label: "80后" },
      { value: "75", label: "75后" },
      { value: "70", label: "70后" },
      { value: "65", label: "65后" },
      { value: "其他", label: "其他" }
    ],
    rules: {
      potentialProjectListSelected: [
        {
          required: true,
          message: '请选择意向项目'
        }
      ],
      potentialLayoutListSelected: [
        {
          required: true,
          message: '请选择意向户型'
        }
      ],
      userType: [
        {
          required: true,
          message: "请选择用户类型"
        }
      ],
      name: [
        {
          required: true,
          message: "请输入姓名"
        }
      ],
      phone: [
        {
          required: true,
          message: "请输入手机号"
        },
        {
          validator: checkPhone
        }
      ],
      subscribeTime: [
        {
          required: true,
          message: "请准确的选择预约时间"
        }
      ],
      subscribeRegion: [
        {
          required: true,
          message: "请选择预约项目"
        }
      ],
      occupation: [
        {
          required: true,
          message: "请选择职业"
        }
      ],
      sex: [
        {
          required: true,
          message: "请选择性别"
        }
      ],
      age: [
        {
          required: true,
          message: "请输入年龄"
        }
      ],
      channel: [
        {
          required: true,
          message: "请选择渠道"
        }
      ],
      layoutName: [
        {
          required: true,
          message: "请选择输入名称"
        }
      ],
      housekeeper: [
        {
          required: true,
          message: "请选择一个管家"
        }
      ],
      // registTime: [
      //   {
      //     required: true,
      //     message: "请输入注册时间"
      //   }
      // ],
      layoutType: [
        {
          required: true,
          message: "请选择意向户型"
        }
      ],
      needStatus: [
        {
          required: true,
          message: "请选择需求状态"
        }
      ],
      price: [
         {
          required: true,
          message: "请选择意向价格"
        }
      ],
      planLiveTime: [
        {
          required: true,
          message: "请输入计划租期"
        },
        {
          validator: checkNumber
        }
      ]
    },
    subscribeProjectList: [],
    potentialProjectList: [],
    potentialLayoutList: [],
    potentialProjectListSelected: [],
    potentialLayoutListSelected: [],
    formModel: {
      cardCode: "",
      cardType: "",
      channel: "SourceUser_Official_website",
      customerType: 1,
      housekeeper: 0,
      id: 0,
      layoutId: 0,
      marryStatus: 0,
      name: "",
      phone: "",
      age: "",
      occupation: "",
      subscribeRegion: "",
      subscribeTime: "",
      seeTime: "",
      seeTimeInterval: 1,

      needStatus: "",
      housekeeperPhone: "",
      planLiveTime: 6,
      userType: 'usr_type_loney',
      price: "1000",
      registTime: "",
      remark: "",
      reserveMsg: "",
      seeTime: "",
      sex: "male",
      status: 1,
      wellCoustProps: [],
      potentialProjectListSelected: [],
      potentialLayoutListSelected: []
    }
  }),
  components: {
    //HelloWorld
  }
}
</script>
<style>
	.ant-modal-footer {
		display: none;
	}
	/*.add-house label {
			font-size: 19px;
		}*/
	  .add-house form textarea.ant-input {
	      height: 80px;
	  }
	  .ant-btn-group > .ant-btn:last-child:not(:first-child) {
	    height: 40px;
	    width: 200px;
	    border-radius: 24px;
	  }
	  .ant-btn-group > .ant-btn:first-child:not(:last-child){
	    height: 40px;
	    width: 200px;
	    border-radius: 24px;
	  }
</style>
<style scoped lang='less'>
	.spec-header {
		position: absolute;
	    top: -15.6px;
	    left: -17px;
	}
    .container_header {
    	margin-bottom: 100px;
  position: relative;
  display: flex;
  justify-content: space-between;
  .header_words{
    z-index: 99;
    position: absolute;
    font-size: 17px;
    left: 6px;
    top: 25px;
    color:#fff;
  }
}
.footer_btn{
  margin-left: 34%;
}
.header_title {
  width: 120px;
  height: 80px;
  .header_img{
    width: 120px;
  }
}
	.add-house {
		.wrapper-title {
			text-align: center;	
			h3 {
				font-size: 40px;
				letter-spacing: 2px;
				font-weight: normal;
			}
			span {
				display: inline-block;
			    width: 10px;
			    height: 10px;
			    background-color: #aacd29;
			    margin: 5px 15px;
			}
		}
		.tips {
			 margin: 0 auto;
		     padding-top: 20px;
		     font-size: 15px;
		     color: #333333;
		     text-align: center;
		     display: flex;
		     .tips__icon{
		       padding-right: 10px;
		       padding-top: 0;
		     }
		}
	}
</style>