import Vue from 'vue'
import { createApp } from './main'
import vueBeauty from 'vue-beauty'
import '@/assets/css/base.css'
import '@/assets/css/vue-beauty.css'
Vue.use(vueBeauty)
import {
      MP
  } from '@/assets/map'

MP('yZCa3f62scCaromUCkPXfnGiB87idDwC')

// 客户端特定引导逻辑……
const { app, store } = createApp()

if (window.__INITIAL_STATE__) {
  store.replaceState(window.__INITIAL_STATE__)
}

// 这里假定 App.vue 模板中根元素具有 `id="app"`
app.$mount('#app')

app.$message.config({
  top: 300,
  duration: 2,
});
window.detailHouseVue = app