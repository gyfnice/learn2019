import Vue from 'vue'
import Router from 'vue-router'

const Index = () => import('./views/index.vue');
const DetailHouse = () => import('./views/detailHouse.vue');
const DetailDynamic = () => import('./views/detailDynamic.vue');
const ListDynamic = () => import('./views/listDynamic.vue');

Vue.use(Router)
export function createRouter() {
  return new Router({
    mode: 'history',
    routes: [
      {
        path: '/',
        name: 'Index',
        component: Index
      },
      {
        path: '/top',
        name: 'Top',
        component: Index
      },
      {
        path: '/detailHouse/:id',
        name: 'detailHouse',
        component: DetailHouse
      },
      {
        path: '/detailDynamic/:id',
        name: 'detailDynamic',
        component: DetailDynamic
      },
      {
        path: '/listDynamic',
        name: 'listDynamic',
        component: ListDynamic
      }
    ]
  })
}
