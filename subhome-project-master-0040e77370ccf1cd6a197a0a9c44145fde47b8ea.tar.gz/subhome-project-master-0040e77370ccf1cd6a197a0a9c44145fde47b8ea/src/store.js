import Vue from "vue";
import Vuex from "vuex";
import api from "@/api/index.js";

Vue.use(Vuex);
export function createStore() {
  return new Vuex.Store({
    state: {
      selectHouseType: {},
      indexArticleList: [],
      publishStatus: 0,
      layoutList: [],
      placeHoldImg: [],
      regionList: [],
      projectList: [],
      articleTopList: [],
      articleOtherList: [],
      articleRecomList: [],
      moreArticleFlag: false,
      regionInfo: {
        status: "",
        keyWords: ""
      },
      spinning: false,
      layoutDetail: {},
      layoutDetailInfo: {
        sumRent: 0.0,
        region: {}
      },
      contentDetail: {
        title: null,
        coverImg: null,
        publishTime: null,
        author: null,
        abstr: null,
        contentDetail: null
      }
    },
    mutations: {
      SET_NORMAL_CONTENT_LIST(state, list) {
        state.articleOtherList = [];
        list.filter(item => {
          state.articleOtherList.push({
            coverImg: api.apiURL + item.coverImg,
            id: item.id,
            title: item.title,
            abstr: item.abstr,
            publishTimeStr: item.publishTimeStr,
            author: item.author
          });
        });
      },
      SET_TOP_CONTENT_LIST(state, list) {
        state.articleTopList = [];
        list.filter(item => {
          state.articleTopList.push({
            coverImg: api.apiURL + item.coverImg,
            id: item.id,
            title: item.title
          });
        });
      },
      SET_RECOMMEND_LIST(state, list) {
        state.articleRecomList = [];
        list.filter(item => {
          state.articleRecomList.push({
            coverImg: api.apiURL + item.coverImg,
            id: item.id,
            title: item.title
          });
        });
      },
      SET_LAYOUT_LIST(state, layoutList) {
        state.layoutList = [];
        state.placeHoldImg = [];
        if (layoutList && layoutList.length > 0) {
          layoutList.map(item => {
            item.coverImg = api.apiURL + item.coverImg;
          });
        }
        Vue.set(state, "layoutList", layoutList);
        var length = layoutList.length;
        if (length < 4) {
          var minusLength = 4 - length;
          for (var i = 0; i < minusLength; i++) {
            state.placeHoldImg.push(i);
          }
        }
      },
      SET_LAYOUT_DETAIL_INFO(state, info) {
        state.layoutDetailInfo = Object.assign(
          {},
          state.layoutDetailInfo,
          info.layout
        );
        state.layoutDetailInfo.sumRent =
          Number(state.layoutDetailInfo.deviceFee) +
          Number(state.layoutDetailInfo.rent);
        if (info.layout.prop) {
          info.layout.prop.map(item => {
            if (item.propCode !== "suppo") {
              item.propValue = api.apiURL + item.propValue;
            }
          });
        }
        state.layoutDetailInfo.imgProps = info.layout.prop;
        state.layoutDetailInfo.region = info.region;
        state.layoutDetailInfo.iconLayoutList = info.layout.prop;
        state.layoutDetailInfo.iconRegionList = info.region.props;
        if (info.otherLayout) {
          info.otherLayout.map(item => {
            item.coverImg = api.apiURL + item.coverImg;
          });
        }
        state.layoutDetailInfo.otherLayoutList = info.otherLayout;
      },
      SET_CONTENT_DETAIL_INFO(state, result) {
        state.contentDetail.title = result.title;
        state.contentDetail.coverImg = api.apiURL + result.coverImg;
        state.contentDetail.publishTime = result.publishTime;
        state.contentDetail.author = result.author;
        state.contentDetail.abstr = result.abstr;
        state.contentDetail.contentDetail = result.contentDetail;
      },
      SET_GLOBAL_SPINNING(state, value) {
        Vue.set(state, "spinning", value);
      },
      SET_INDEX_HOT_LIST(state, data) {
        state.indexArticleList = [];
        data.filter(res => {
          state.indexArticleList.push({
            coverImg: api.apiURL + res.coverImg,
            id: res.id,
            title: res.title
          });
        });
      },
      GET_SELECT_HOUSE_TYPE(state, data) {
        Vue.set(state, data.keyName, data.list);
        //state.selectHouseType[data.keyName] = data.list;
        //Vue.set(state, 'selectHouseType', data)
        //Object.assign({}, state.selectHouseType, data)
      },
      SET_REGION_LIST(state, data) {
        let list = data.map(item => {
          return {
            label: item.name,
            value: item.id
          };
        });
        Vue.set(state, "regionList", list);
      }
    },
    actions: {
      getAllContentTypeList({ commit, state }, params) {
        return api
          .request(
            "get",
            api.getURL("contentSailWebsite/allAndDiffList"),
            params
          )
          .then(res => {
            if (res.data.code === 10000) {
              let result = res.data.data;
              if (result.listOther.endRow < 9) {
                state.moreArticleFlag = false;
              } else {
                state.moreArticleFlag = true;
              }
              commit("SET_NORMAL_CONTENT_LIST", result.listOther.list);
              commit("SET_TOP_CONTENT_LIST", result.listTop);
              commit("SET_RECOMMEND_LIST", result.listRcom);
            }
            return res;
          });
      },
      getLayoutListByRegionId({ commit, state }, params) {
        return api
          .request("get", api.getURL("houseSailWebsite/listLayout"), params)
          .then(res => {
            if (res.data.code === 10000) {
              commit("SET_LAYOUT_LIST", res.data.data);
            }
            return res;
          });
      },
      fetchLayoutDetail({ commit, state }, params) {
        return api
          .request("get", api.getURL("houseSailWebsite/layoutDetail"), params)
          .then(res => {
            if (res.data.code === 10000) {
              commit("SET_LAYOUT_DETAIL_INFO", res.data.data);
              return res;
            }
          });
      },
      fetchContentDetail({ commit, state }, params) {
        return api
          .request("get", api.getURL("contentSailWebsite/detail"), params)
          .then(res => {
            if (res.data.code === 10000) {
              commit("SET_CONTENT_DETAIL_INFO", res.data.data);
              return res;
            }
          });
      },
      addItem({ commit, state }, data) {
        let url = api.getURL("wellCustomer/insert");
        return api.request("post", url, data);
      },
      listRegion({ commit, state, dispatch }, hasLayout) {
        return api
          .request("get", api.getURL("houseSailWebsite/listRegion"), {
            num: 2
          })
          .then(res => {
            if (res.data.code === 10000) {
              state.projectList = res.data.data;
              if (hasLayout) {
                let defaultRegionId = res.data.data[0].id;
                return dispatch("getLayoutListByRegionId", {
                  regionId: defaultRegionId
                });
              }
            }
            return res;
          });
      },
      topList({ commit, state }, params) {
        return api
          .request("get", api.getURL("contentSailWebsite/topList"), {
            num: 3
          })
          .then(res => {
            commit("SET_INDEX_HOT_LIST", res.data.data);
            return res;
          });
      },
      regionFetchRegionList({ commit, state }, params) {
        //获取项目管理List列表
        let { currentPage, pageSize } = params;
        //if (state.cache && cache) return;
        return api
          .request("get", api.getURL("houseSailWebsite/listRegion"), {
            num: 10
          })
          .then(res => {
            if (!res) return;
            //console.log(res)
            let data = res.data;
            commit("SET_REGION_LIST", data.data);
            return data;
          });
      },
      fetchSelectHouseType({ commit, state }, typeName) {
        //if (state.selectHouseType.length > 0) return;
        if (state.selectHouseType[typeName])
          return state.selectHouseType[typeName]; //对已缓存的数据无需发送请求
        return api
          .request("get", api.getURL("dictionary/selectByPCode"), {
            code: typeName
          })
          .then(res => {
            if (!res) return;
            let data = res.data;
            //console.log(data);
            let opt = data.data.map(item => {
              return {
                value: item.value,
                label: item.name || item.remark
              };
            });
            commit("GET_SELECT_HOUSE_TYPE", {
              list: opt,
              keyName: typeName
            });
            return opt;
          });
      }
    }
  })
}
