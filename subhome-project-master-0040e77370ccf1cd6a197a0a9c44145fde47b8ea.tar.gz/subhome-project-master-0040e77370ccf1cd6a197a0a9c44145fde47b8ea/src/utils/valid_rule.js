//验证规则相关
//房源编码规格校验
export const checkHouseFormat = (rule, value, callback) => {
  if(value && value.length !== 8) {
    callback(new Error("请输入正确的编号，如：A1010204, 每个单元格只允许包含2个字符"))
  }else {
    callback()
  }
};

//手机校验
export const checkPhone = (rule, value, callback) => {
  if (!/^\d+$/.test(value)) {
    callback(new Error("请输入正确的手机号"));
  } else if (value.length!=11) {
    callback(new Error('手机号不正确'))
  } else {
    callback();
  }
};

//排序校验
export const checkSort = (rule, value, callback) => {
  if (!/^\d+$/.test(value)) {
    if(value.length>3){
      callback(new Error("请输入小于3位的排序数字"));
    }
    callback(new Error("请输入正确的排序数字"));
  } else {
    callback();
  }
};
export const checkNumberSort = (rule, value, callback) => {
    var sort = parseInt(value, 10);
    if (!Number.isInteger(sort)) {
          callback(new Error('请输入数字值'));
      } else {
          if (sort > 1000) {
              callback(new Error('排序数字必须小于1000'));
          }else if(sort <= 0){
               callback(new Error('排序数字必须大于0'));
          } else {
              callback();
          }
      }
};
//数字验证
export const checkNumber = (rule, value, callback) => {
  if (!/^\d+$/.test(value)) {
    callback(new Error("请输入数字"));
  } else {
    callback();
  }
};

//小数点后两位验证
export const checkDoubleNumber = (rule, value, callback) => {
  var pattern =/^[0-9]+([.]\d{2})?$/;
  if (!pattern.test(value)) {
    callback(new Error("请输入数字(例:0.00),最高保留两位小数"));
  } else {
    callback();
  }
};

//验证数字长度，
export const checkNumerLength = (rule, value, callback) => {
  if (value.length > 2) {
    callback(new Error("不得超过2位"));
  } else {
    callback();
  }
};

//验证字符长度
export const checkTextLength = (rule, value, callback) => {
  if (value.length > 20) {
    callback(new Error("不得超过20位"));
  } else {
    callback();
  }
};
