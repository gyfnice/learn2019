<template>
   <div id="detailArticleVue">
      <header class="s-header">
             <nav class="s-navbar">
                 <div class="s-navbar-left pull-left">
                     <router-link to="/"><img src="@/assets/img/home_pic_navlogo.png" class="logo"></router-link>
                 </div>
                 <div class="s-navbar-right pull-right">
                     <ul class="nav-list">
                         <li><router-link to="/" class="return-index">赛领首页</router-link></li>
                     </ul>
                 </div>
             </nav>
         </header>
         <section class="floor detail-floor padding-100" id="articleDetailBox">
             <div class="detail-tit" v-if="isShow">
                 <div class="detail-tit-img"><img v-bind:src="contentDetail.coverImg"></div>
                 <div class="detail-tit-intro" >
                     <h3>{{contentDetail.title}}</h3>
                     <div class="detail-tit-bot"><span class="time">{{contentDetail.publishTime}}</span><span class="source">{{contentDetail.author}}</span></div>
                 </div>
             </div>
             <div class="detail-titFont" v-if="!isShow">
                 <div class="detail-tit-intro">
                     <h3>{{contentDetail.title}}</h3>
                     <div class="detail-tit-bot"><span class="time">{{contentDetail.publishTime}}</span><span class="source">{{contentDetail.author}}</span></div>
                 </div>
             </div>
             <v-spin v-if="spinning">
               <v-alert type="info" message="正在加载数据"
                  description="请耐心等待"
                ></v-alert>
             </v-spin>
             <div class="abstract">
                 <dt class="abstract-tit">摘要：</dt>
                 <dd class="abstract-intro">{{contentDetail.abstr}}</dd>
             </div>
             <div class="text-area" v-html="contentDetail.contentDetail"></div>
         </section>
         <footer class="sail-footer">
         <div class="floor">
             <div class="foot-img">
                 <span class="pull-left"><img src="@/assets/img/home_pic_bottom.png" class="slogan"></span>
                 <span class="pull-right"><img src="@/assets/img/index_wechat.jpg" class="qcodeImg"><p class="qfont">扫码关注微信公众号</p></span>
             </div>
             <div class="foot-con">
                 <p>联系电话：400-120-2019</p>
                 <p>©2017 贵阳置业担保有限公司. All Rights Reserved.</p>
                 <p>黔ICP备16016494号-1</p>
             </div>
         </div>
     </footer>
   </div>
</template>

<script>
  import { mapState } from 'vuex'
  import api from "@/api/index.js";
  export default {
    name: 'detailArticleVue',
    components: {

    },
    computed: {
        ...mapState({
             contentDetail: state => state.contentDetail,
             spinning: state => state.spinning
        }),
        isShow:function () {
              if(this.contentDetail.coverImg !== ''){
                  return true;
              }else {
                  return false;

              }
        }
    },
    data:function() {
	   	return {
	          
	    }
    },
    methods:{},
    asyncData({store, route}) {
        let articleDetailId = route.params.id;
        return store.dispatch('fetchContentDetail', {
          id: articleDetailId
        })
    },
    mounted() {
    	window.scrollTo(0,0)
    },
  }
</script>
<style>
	#detailArticleVue {
		font-size: 16px;
	}
	.BMap_bubble_title {
		font-weight: bold;
		font-size: 15px;
		color: #333;
	}

	.BMap_bubble_content {
		font-size: 15px;
		color: #333;
	}
    .text-area img {
        width: 100%;
    }
</style>
<style scoped lang='less'>
	.sub-btn {
		width:182px;
		height:50px;
		background:rgba(0,119,57,1);
		border-radius:27px;
		box-shadow:0px 3px 6px rgba(0,0,0,0.16);
		text-align: center;
		line-height: 50px;
		color: white;
		margin-left: 92px;
		cursor: pointer;
	}
    .list-floor .floor-title{
        margin: 50px 0 50px;
    }
    .return-index{
        color: #007739;
    }
    .return-index:hover{
        color: #017337;
    }
    .list-dynamic{
        margin-top: 50px;
        background-color: #f7f7f7;
    }
    .list-dynamic-left{
        background-color: #fff;
        padding-right: 30px;
        min-height: 800px;
    }
    .list-dynamic-left .layout{
        width: 820px;
        padding-top: 40px;
        border-top: 1px solid #ddd;
        margin-bottom: 40px;
    }
    .list-dynamic-left .first-layout a{
        display: flex;
    }
    .list-dynamic-left .first-layout .layout-img{
        width: 235px;
        height: 165px;
        margin-right: 30px;
    }
    .list-dynamic-left .first-layout .layout-img img{
        width: 235px;
        height: 165px;
    }
    .layout-font h3{
        font-size: 18px;
        font-weight: normal;
        margin-bottom: 15px;
    }
    .layout-font p{
        font-size: 16px;
        color: #666;
        margin-bottom: 15px;
        line-height: 26px;
    }
    .layout-font .font-bot{
        font-size: 14px;
        color: #666;
    }
    .layout-font .font-bot .time{
        margin-right: 10px;
    }
    .list-dynamic-left .second-layout .layout-img{
        margin-bottom: 15px;
    }
    .list-dynamic-left .second-layout .layout-img img{
        width: 360px;
        height: 240px;
    }

    .list-dynamic-right{
        width: 350px;
    }
    .list-dynamic-right .recommend-tit{
        padding: 5px 10px;
        font-size: 18px;
        letter-spacing: 1px;
        color: #007739;
        border-left: 3px solid #007739;
    }
    .list-dynamic-right .group{
        padding: 15px;
    }
    .list-dynamic-right .first-group{
        position: relative;
    }
    .list-dynamic-right .first-group .group-big-img{
        height: 215px;
    }
    .list-dynamic-right .first-group .group-big-img img{
        height: 215px;
        width: 100%;
    }
    .list-dynamic-right .first-group .group-tit{
        position: absolute;
        padding: 5px 10px;
        bottom: 15px;
        right: 15px;
        left: 15px;
        background-color: rgba(0,0,0,.3);
    }
    .list-dynamic-right .first-group .group-tit h3{
        font-weight: normal;
        font-size: 16px;
        text-align: center;
        height: 24px;
        overflow: hidden;
        color: #fff;
    }
    .group .group-font{
        margin-top: 15px;
    }
    .group .group-font h3:before{
        content: '▪';
        font-size: 20px;
        padding-right: 8px;
        vertical-align: bottom;
        line-height: 21px;
    }
    .group .group-font h3{
        color: #000;
        font-size: 16px;
        font-weight: normal;
    }
    .group .group-block{
        margin-top: 15px;
        display: flex;
    }
    .group .group-block .group-small-img{
        height: 175px;
        width: 155px;
    }
    .group .group-block .group-small-img img{
        height: 175px;
        width: 155px;
    }
    .group .group-block .group-intro{
        margin-left: 20px;
        font-size: 14px;
        color: #666;
        line-height: 22px;
    }

    .detail-floor .detail-tit{
        position: relative;
        margin-top: 50px;
    }
    .detail-tit .detail-tit-img{
        text-align: center;
        height: 380px;
        width: 640px;
        margin: 0 auto;
        border: 1px solid #ddd;
    }
    .detail-tit .detail-tit-img img{
        height: 380px;
        width: 100%;
    }
    .detail-tit .detail-tit-intro{
        padding: 30px 20px 10px;
        color: #333;
    }
    .detail-tit .detail-tit-intro h3{
        padding-top: 5px;
        letter-spacing: 2px;
        font-size: 32px;
        font-weight: normal;
    }
    .detail-floor .detail-titFont{
        padding-top: 150px;
        position: relative;
    }
    .detail-titFont .detail-tit-intro{
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        padding: 10px 20px;
        color: #333;
    }
    .detail-titFont .detail-tit-intro h3{
        padding-top: 5px;
        letter-spacing: 2px;
        font-size: 32px;
        font-weight: normal;
    }
    .detail-tit-bot{
        font-size: 18px;
        padding: 10px 0;
        color: #666;
    }
    .detail-tit-bot .time{
        margin-right: 10px;
    }
    .abstract{
        margin-top: 40px;
        padding: 20px;
        background-color: #f7f7f7;
    }
    .abstract .abstract-tit{
        font-size: 18px;
        font-weight: bold;
    }
    .abstract .abstract-intro{
        margin-top: 10px;
        font-size: 16px;
        line-height: 30px;
        text-indent: 35px;
    }
    .text-area{
        margin: 20px;
        line-height: 35px;
    }
    .text-area p{
        margin: 0;
        padding: 0;
    }
    .floor-house .floor-title{
        margin: 80px 0 0;
    }
    .house-item{
        margin-top: 60px;
    }
    .house-item .house-intro{
        display: flex;
        display: -webkit-flex;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
    }
    .house-item .house-intro .house-intro-l{
        width: 580px;
        overflow: hidden;
        position: relative;
    }
    .house-intro .house-intro-l .imgVideo{
        width: 100%;
        height: 380px;
        background-color: #000;
        position: relative;
        text-align: center;
        overflow: hidden;
    }
    .house-intro .house-intro-l .imgVideo .imgSize{
        height: 380px;
        width: 580px;
        position: relative;
        text-align: center;
    }
    .house-intro .house-intro-l .imgVideo .imgSize video{
        height: 380px;
        width: 100%;
    }
    #playBtn{
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -25px;
        margin-left: -25px;
        cursor: pointer;
    }
    #playBtn img{
        width: 50px;
        height: 50px;
    }
    .layoutImg{
        display: flex;
        width: 100%;
        overflow: hidden;
    }
    .layoutImg li{
        width: 580px;
        height: 380px;
        position: relative;
    }
    .layoutImg li img{
        width: 580px;
        height: 380px;
    }
    .layoutState li{
        position: absolute;
        font-size: 12px;
        top: 10px;
        right: 10px;
        width: 40px;
        height: 20px;
        line-height: 20px;
        background-color: rgba(0,0,0,.2);
        color: #fff;
        border-radius: 20px;
    }
    .imgVideo .prev, .imgVideo .next{
        cursor: pointer;
        position: absolute;
        left: 10px;
        top: 50%;
        margin-top: -25px;
        display: block;
        width: 32px;
        height: 40px;
        background: url(../assets/img/slider-arrow.png) -110px 5px no-repeat;
        filter: alpha(opacity=50);
        opacity: 0.5;
    }
    .imgVideo .next{
        left: auto;
        right: 10px;
        background-position: 8px 5px;
    }
    .imgVideo .prev:hover, .imgVideo .next:hover{
        filter: alpha(opacity=100);
        opacity: 1;
    }
    .house-intro .house-intro-l .intro-l-tit{
        position: absolute;
        left: 0;
        right: 0;
        background-color: rgba(0,0,0,.3);
        bottom: 0;
    }
    .house-intro .house-intro-l .intro-l-tit .tit-text{
        padding: 10px 20px;
        color: #fff;
        font-weight: normal;
    }
    .house-item .house-intro .house-intro-r{
        width: 590px;
        margin-left: 30px;
    }
    .house-item-tit{
        position: relative;
        text-align: center;
    }
    .house-item-tit .tit-text{
        display: inline-block;
        background-color: #fff;
        padding: 0 20px;
        font-size: 26px;
        font-weight: normal;
    }
    .house-item-tit:after{
        content: '';
        position: absolute;
        width: 100%;
        height: 2px;
        left: 0;
        background-color: #ddd;
        z-index: -1;
        top: 16px;
    }
    .house-intro-r .house-intro-list{
        margin: 20px;
        color: #666;
    }
    .house-intro-r .house-intro-list li{
        padding: 5px 0;
    }
    .house-intro-r .house-intro-list li b{
        text-align: right;
        font-weight: normal;
        width: 120px;
        display: inline-block;
    }
    .house-intro-r .house-intro-list li span{
        margin-left: 15px;
        text-align: left;
    }

    .house-item-icon{
        margin: 30px -20px 0;
        display: flex;
        display: -webkit-flex;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
    }
    .house-item-icon li{
        padding: 15px 20px;
        width: 110px;
        text-align: center;
        color: #666;
    }
    .house-item-icon li .iconfont{
        font-size: 42px;
    }
    .house-item-icon li p{
        padding-top: 5px;
    }
    .house-item .house-project-intro{
        margin-top: 50px;
        padding: 20px;
        line-height: 32px;
        background-color: #f7f7f7;
    }
    .house-item .house-round{
        margin-top: 50px;
        line-height: 32px;
    }
    .map-guide{
        width: 100%;
        height: 600px;
        margin-top: 40px;
        text-align: center;
    }
    .fy-house-round{
        margin-top: 50px;
    }
</style>