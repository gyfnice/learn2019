<template>
   <div id="detailHouse">
       <addHouse :visible="visible" @hide="hideModal"></addHouse>
   			<header class="s-header">
   				<nav class="s-navbar">
   					<div class="s-navbar-left pull-left">
   						<router-link to="/">
   							<img src="@/assets/img/home_pic_navlogo.png" class="logo">
   						</router-link>
   					</div>
   					<div class="s-navbar-right pull-right">
   						<ul class="nav-list">
   							<li>
   								<router-link to="/" class="return-index">赛领首页</router-link>
   							</li>
   						</ul>
   					</div>
   				</nav>
   			</header>
   			<section class="floor floor-house padding-100" id="houseDetailBox">
   				<div class="floor-title">
   					<h3>赛领
   						<span></span>{{layoutDetailInfo.region.name}}</h3>
   				</div>
          <v-spin v-if="spinning">
            <v-alert type="info" message="正在加载数据"
               description="请耐心等待"
             ></v-alert>
          </v-spin>
   				<div class="floor-body">
   					<div class="house-item">
   						<div class="house-intro">
   							<div class="house-intro-l">
   								<div class="imgVideo">
   									<ul class="layoutImg">
   										<li v-if="layoutDetailInfo.video!=''">
   											<div class="imgSize">
   												<video id="myVideo" width="580" height="380" :src="layoutDetailInfo.video" poster="img/home_pic_news1.jpg" type="video/mp4"></video>
   												<span id="playBtn">
   													<img src="@/assets/img/paly.png">
   												</span>
   											</div>
   										</li>
   										<li v-if="value.propCode=='showImg'" v-for="value in layoutDetailInfo.imgProps" style="float: left;">
   											<img :src="value.propValue" v-bind:class="imgSize">
   										</li>
   									</ul>
   									<a class="prev"></a>
   									<a class="next"></a>
   									<ul class="layoutState">
   										<li class="pageState">
   											<span>1</span>/6</li>
   									</ul>
   								</div>
   								<div class="intro-l-tit" style="display: none;">
   									<h3 class="tit-text">{{layoutDetailInfo.layoutName}} . ￥{{layoutDetailInfo.rent}}</h3>
   								</div>
   							</div>
   							<div class="house-intro-r">
   								<div class="house-item-tit">
   									<h3 class="tit-text">户型详情</h3>
   								</div>
   								<ul class="house-intro-list">
   									<li>
   										<b>户型：</b>
   										<span>{{layoutDetailInfo.layoutName}}</span>
   									</li>
   									<li>
   										<b>面积：</b>
   										<span>{{layoutDetailInfo.acreage}}m²</span>
   									</li>
   									<li>
   										<b>租金：</b>
   										<span>{{layoutDetailInfo.sumRent && layoutDetailInfo.sumRent.toFixed(2)}}元</span>
   									</li>
   									<li>
   										<b>押金：</b>
   										<span>{{layoutDetailInfo.deposit}}元</span>
   									</li>
   									<li>
   										<b>位置：</b>
   										<span>{{layoutDetailInfo.region.provinceName}}{{layoutDetailInfo.region.cityName}}{{layoutDetailInfo.region.districtName}}{{layoutDetailInfo.region.address}}</span>
   									</li>
   								</ul>
   								<div class="sub-btn" @click="openModal">预约看房</div>
   							</div>
   						</div>
   						<ul class="house-item-icon">
   							<li v-if="value.propCode=='suppo'" v-for="value in layoutDetailInfo.iconLayoutList">
   								<i :class="value.propValue"></i>
   								<p>{{value.propValueDesc}}</p>
   							</li>
   						</ul>
   					</div>
   					<div class="house-item">
   						<div class="house-item-tit">
   							<h3 class="tit-text">项目简介</h3>
   						</div>
   						<div class="house-project-intro">
   							<p v-html="layoutDetailInfo.region.abstracts"></p>
   						</div>
   						<ul class="house-item-icon">
   							<li v-if="value.propCode=='suppo'" v-for="value in layoutDetailInfo.iconRegionList">
   								<i :class="value.propValue"></i>
   								<p>{{value.propValueDesc}}</p>
   							</li>
   						</ul>
   					</div>
   					<div class="house-item">
   						<div class="house-item-tit">
   							<h3 class="tit-text">周边详情</h3>
   						</div>
   						<div class="map-guide" id="container"></div>
   					</div>
   					<div class="house-item">
   						<div class="house-item-tit">
   							<h3 class="tit-text">其它户型</h3>
   						</div>
   						<div class="fy-slider fy-house-round">
   							<ul class="fy-list">
   								<li class="imgBox" v-for="value in layoutDetailInfo.otherLayoutList" @mouseenter="imgEnter" @mouseleave="imgLeave">
   									<div class="slid-img">
   										<img :src="value.coverImg">
   									</div>
   									<div class="slid-fade">
   										<div class="slid-mask" style="display: none"></div>
   										<div class="slid-con">
   											<p class="bot-font">{{value.layoutName}} . ￥{{value.rent}}/月</p>
   											<router-link :to="`/detailHouse/${value.id}`" class="desc-btn">查看详情</router-link>
   										</div>
   									</div>
   								</li>
   							</ul>
   							<div class="clear"></div>
   						</div>
   					</div>
   				</div>
   			</section>
   			<footer class="sail-footer">
   				<div class="floor">
   					<div class="foot-img">
   						<span class="pull-left">
   							<img src="@/assets/img/home_pic_bottom.png" class="slogan">
   						</span>
   						<span class="pull-right">
   							<img src="@/assets/img/index_wechat.jpg" class="qcodeImg">
   							<p class="qfont">扫码关注微信公众号</p>
   						</span>
   					</div>
   					<div class="foot-con">
   						<p>联系电话：400-120-2019</p>
   						<p>©2017 贵阳置业担保有限公司. All Rights Reserved.</p>
   						<p>黔ICP备18006675号-2</p>
   					</div>
   				</div>
   			</footer>
   </div>
</template>

<script>
  import {
      MP
  } from '@/assets/map'
  import { mapState } from 'vuex'
  import addHouse from '@/components/addHouse'
  import api from "@/api/index.js";
  
  export default {
    name: 'gyfnice',
    components: {
      addHouse
    },
    computed: {
       ...mapState({
          layoutDetailInfo: state => state.layoutDetailInfo,
          spinning: state => state.spinning
       })
    },
    beforeRouteUpdate(to, from, next) {
        let id = to.params.id;
        let houseDetailId = to.params.id;
        this.$store.dispatch('fetchLayoutDetail', {
          id: houseDetailId,
          num: 4
        })
        window.scrollTo(0,0)
        next()
    },
    mounted() {
     //let that = this;
          let that = this;
          that.$nextTick(function() {
                MP('yZCa3f62scCaromUCkPXfnGiB87idDwC') //ak改成你的ak
                    .then(BMap => {
                      //添加提示信息
                      function addShowTtitile(map, marker, point) {
                        var opts = {
                          width: 360, // 信息窗口宽度
                          height: 100, // 信息窗口高度
                          borderColor: '#ddd',
                          title: that.layoutDetailInfo.region.name, // 信息窗口标题
                          enableMessage: true, //设置允许信息窗发送短息
                        };
                        var infoWindow = new BMap.InfoWindow('地址：' + that.layoutDetailInfo.region.provinceName + that.layoutDetailInfo.region.cityName +
                          that.layoutDetailInfo.region.districtName + that.layoutDetailInfo.region.address, opts); // 创建信息窗口对象
                        map.openInfoWindow(infoWindow, point);
                      }

                      //添加控件
                      function addControl(map) {
                        var navigationControl = new BMap.NavigationControl({
                          // 靠左上角位置
                          anchor: BMAP_ANCHOR_TOP_LEFT,
                          // LARGE类型
                          type: BMAP_NAVIGATION_CONTROL_LARGE,
                          // 启用显示定位
                          enableGeolocation: true
                        });
                        map.addControl(navigationControl);

                        navigator.geolocation.getCurrentPosition(function (position) {

                          //得到html5定位结果
                          var x = position.coords.longitude;
                          var y = position.coords.latitude;

                          //由于html5定位的结果是国际标准gps，所以from=1，to=5
                          //下面的代码并非实际是这样，这里只是提供一个思路
                          BMap.convgps(x, y, 1, 5, function (convRst) {
                            var point = new BMap.Point(convRst.x, convRst.y);

                            //这个部分和上面的代码是一样的
                            var marker = new BMap.Marker(point);
                            map.addOverlay(marker);
                            map.panTo(point);
                            alert('您的位置：' + r.point.lng + ',' + r.point.lat);
                          })

                        })
                        // 添加定位控件
                        var geolocationControl = new BMap.GeolocationControl();
                        geolocationControl.addEventListener("locationSuccess",
                          function (e) {
                            // 定位成功事件
                            var address = '';
                            address += e.addressComponent.province;
                            address += e.addressComponent.city;
                            address += e.addressComponent.district;
                            address += e.addressComponent.street;
                            address += e.addressComponent.streetNumber;
                            alert("当前定位地址为：" + address);
                          });
                        geolocationControl.addEventListener("locationError",
                          function (e) {
                            // 定位失败事件
                            alert(e.message);
                          });
                        map.addControl(geolocationControl);
                      }

                        setTimeout(() => {
                          console.log('baiduMap---->')
                          var map = new BMap.Map('container');
                          
                          var point = new BMap.Point(that.layoutDetailInfo.region.longitude, that.layoutDetailInfo.region.latitude);
                         
                          // 初始化地图， 设置中心点坐标和地图级别
                          map.centerAndZoom(point, 12);

                          addControl(map);

                          // 添加点覆盖物
                          map.setCurrentCity("贵阳");

                          var marker = new BMap.Marker(point);
                          addShowTtitile(map, marker, point);
                          map.addOverlay(marker);
                        }, 5000)
                    })
            })
          window.scrollTo(0,0)
          this.dataPromise.then(res => {
            this.initSlide()
          })
    },
    asyncData({store, route}) {
      let houseDetailId = route.params.id;
        //this.houseDetailId = sessionStorage.getItem('house-detail-id');
      return store.dispatch('fetchLayoutDetail', {
        id: houseDetailId,
        num: 4
      })
    },
    data: function() {
      return {
         visible: false,
         detailSpinning: false,
         imgSize:true,
      };
    },
    methods: {
    	hideModal() {
    	  this.visible = false;
    	},
    	openModal() {
    	  this.visible = true;
    	},
      initSlide() {
        $(".imgVideo").slide({
          mainCell: ".layoutImg",
          effect: 'left',
          autoPlay: false,
          prevCell: '.prev',
          nextCell: '.next',
          trigger: 'click'
        });

        //video setting
        var video = document.getElementById('myVideo');
        var playBtn = document.getElementById('playBtn')
        if(playBtn) {
          playBtn.onclick = function () {
            playBtn.style.display = 'none';
            if (video.paused) {
              video.play();
            } else {
              video.pause();
            }
          };
        }
        if(video) {
          video.onclick = function () {
            playBtn.style.display = 'block';
            this.pause();
          };
        }
      },
    	imgEnter:function (event) {
	        $(event.target).find('.slid-mask').fadeIn(200);
	        $(event.target).find('.slid-con').css('bottom','50%');
    	},
    	imgLeave:function (event) {
	        $(event.target).find('.slid-mask').fadeOut(200);
	        $(event.target).find('.slid-con').css('bottom','-10px');
    	}
    }
  }
</script>
<style>
	#detailHouse {
		font-size: 16px;
	}
	.BMap_bubble_title {
		font-weight: bold;
		font-size: 15px;
		color: #333;
	}

	.BMap_bubble_content {
		font-size: 15px;
		color: #333;
	}
</style>
<style scoped lang='less'>
	.sub-btn {
		width:182px;
		height:50px;
		background:rgba(0,119,57,1);
		border-radius:27px;
		box-shadow:0px 3px 6px rgba(0,0,0,0.16);
		text-align: center;
		line-height: 50px;
		color: white;
		margin-left: 92px;
		cursor: pointer;
	}
    .list-floor .floor-title{
        margin: 50px 0 50px;
    }
    .return-index{
        color: #007739;
    }
    .return-index:hover{
        color: #017337;
    }
    .list-dynamic{
        margin-top: 50px;
        background-color: #f7f7f7;
    }
    .list-dynamic-left{
        background-color: #fff;
        padding-right: 30px;
        min-height: 800px;
    }
    .list-dynamic-left .layout{
        width: 820px;
        padding-top: 40px;
        border-top: 1px solid #ddd;
        margin-bottom: 40px;
    }
    .list-dynamic-left .first-layout a{
        display: flex;
    }
    .list-dynamic-left .first-layout .layout-img{
        width: 235px;
        height: 165px;
        margin-right: 30px;
    }
    .list-dynamic-left .first-layout .layout-img img{
        width: 235px;
        height: 165px;
    }
    .layout-font h3{
        font-size: 18px;
        font-weight: normal;
        margin-bottom: 15px;
    }
    .layout-font p{
        font-size: 16px;
        color: #666;
        margin-bottom: 15px;
        line-height: 26px;
    }
    .layout-font .font-bot{
        font-size: 14px;
        color: #666;
    }
    .layout-font .font-bot .time{
        margin-right: 10px;
    }
    .list-dynamic-left .second-layout .layout-img{
        margin-bottom: 15px;
    }
    .list-dynamic-left .second-layout .layout-img img{
        width: 360px;
        height: 240px;
    }

    .list-dynamic-right{
        width: 350px;
    }
    .list-dynamic-right .recommend-tit{
        padding: 5px 10px;
        font-size: 18px;
        letter-spacing: 1px;
        color: #007739;
        border-left: 3px solid #007739;
    }
    .list-dynamic-right .group{
        padding: 15px;
    }
    .list-dynamic-right .first-group{
        position: relative;
    }
    .list-dynamic-right .first-group .group-big-img{
        height: 215px;
    }
    .list-dynamic-right .first-group .group-big-img img{
        height: 215px;
        width: 100%;
    }
    .list-dynamic-right .first-group .group-tit{
        position: absolute;
        padding: 5px 10px;
        bottom: 15px;
        right: 15px;
        left: 15px;
        background-color: rgba(0,0,0,.3);
    }
    .list-dynamic-right .first-group .group-tit h3{
        font-weight: normal;
        font-size: 16px;
        text-align: center;
        height: 24px;
        overflow: hidden;
        color: #fff;
    }
    .group .group-font{
        margin-top: 15px;
    }
    .group .group-font h3:before{
        content: '▪';
        font-size: 20px;
        padding-right: 8px;
        vertical-align: bottom;
        line-height: 21px;
    }
    .group .group-font h3{
        color: #000;
        font-size: 16px;
        font-weight: normal;
    }
    .group .group-block{
        margin-top: 15px;
        display: flex;
    }
    .group .group-block .group-small-img{
        height: 175px;
        width: 155px;
    }
    .group .group-block .group-small-img img{
        height: 175px;
        width: 155px;
    }
    .group .group-block .group-intro{
        margin-left: 20px;
        font-size: 14px;
        color: #666;
        line-height: 22px;
    }

    .detail-floor .detail-tit{
        position: relative;
        margin-top: 50px;
    }
    .detail-tit .detail-tit-img{
        text-align: center;
        height: 380px;
        width: 640px;
        margin: 0 auto;
        border: 1px solid #ddd;
    }
    .detail-tit .detail-tit-img img{
        height: 380px;
        width: 100%;
    }
    .detail-tit .detail-tit-intro{
        padding: 30px 20px 10px;
        color: #333;
    }
    .detail-tit .detail-tit-intro h3{
        padding-top: 5px;
        letter-spacing: 2px;
        font-size: 32px;
        font-weight: normal;
    }
    .detail-floor .detail-titFont{
        padding-top: 150px;
        position: relative;
    }
    .detail-titFont .detail-tit-intro{
        position: absolute;
        bottom: 0;
        right: 0;
        left: 0;
        padding: 10px 20px;
        color: #333;
    }
    .detail-titFont .detail-tit-intro h3{
        padding-top: 5px;
        letter-spacing: 2px;
        font-size: 32px;
        font-weight: normal;
    }
    .detail-tit-bot{
        font-size: 18px;
        padding: 10px 0;
        color: #666;
    }
    .detail-tit-bot .time{
        margin-right: 10px;
    }
    .abstract{
        margin-top: 40px;
        padding: 20px;
        background-color: #f7f7f7;
    }
    .abstract .abstract-tit{
        font-size: 18px;
        font-weight: bold;
    }
    .abstract .abstract-intro{
        margin-top: 10px;
        font-size: 16px;
        line-height: 30px;
        text-indent: 35px;
    }
    .text-area{
        margin: 20px;
        line-height: 35px;
    }
    .text-area p{
        margin: 0;
        padding: 0;
    }
    .floor-house .floor-title{
        margin: 80px 0 0;
    }
    .house-item{
        margin-top: 60px;
    }
    .house-item .house-intro{
        display: flex;
        display: -webkit-flex;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
    }
    .house-item .house-intro .house-intro-l{
        width: 580px;
        overflow: hidden;
        position: relative;
    }
    .house-intro .house-intro-l .imgVideo{
        width: 100%;
        height: 380px;
        background-color: #000;
        position: relative;
        text-align: center;
        overflow: hidden;
    }
    .house-intro .house-intro-l .imgVideo .imgSize{
        height: 380px;
        width: 580px;
        position: relative;
        text-align: center;
    }
    .house-intro .house-intro-l .imgVideo .imgSize video{
        height: 380px;
        width: 100%;
    }
    #playBtn{
        position: absolute;
        top: 50%;
        left: 50%;
        margin-top: -25px;
        margin-left: -25px;
        cursor: pointer;
    }
    #playBtn img{
        width: 50px;
        height: 50px;
    }
    .layoutImg{
        display: flex;
        width: 100%;
        overflow: hidden;
    }
    .layoutImg li{
        width: 580px;
        height: 380px;
        position: relative;
    }
    .layoutImg li img{
        width: 580px;
        height: 380px;
    }
    .layoutState li{
        position: absolute;
        font-size: 12px;
        top: 10px;
        right: 10px;
        width: 40px;
        height: 20px;
        line-height: 20px;
        background-color: rgba(0,0,0,.2);
        color: #fff;
        border-radius: 20px;
    }
    .imgVideo .prev, .imgVideo .next{
        cursor: pointer;
        position: absolute;
        left: 10px;
        top: 50%;
        margin-top: -25px;
        display: block;
        width: 32px;
        height: 40px;
        background: url(../assets/img/slider-arrow.png) -110px 5px no-repeat;
        filter: alpha(opacity=50);
        opacity: 0.5;
    }
    .imgVideo .next{
        left: auto;
        right: 10px;
        background-position: 8px 5px;
    }
    .imgVideo .prev:hover, .imgVideo .next:hover{
        filter: alpha(opacity=100);
        opacity: 1;
    }
    .house-intro .house-intro-l .intro-l-tit{
        position: absolute;
        left: 0;
        right: 0;
        background-color: rgba(0,0,0,.3);
        bottom: 0;
    }
    .house-intro .house-intro-l .intro-l-tit .tit-text{
        padding: 10px 20px;
        color: #fff;
        font-weight: normal;
    }
    .house-item .house-intro .house-intro-r{
        width: 590px;
        margin-left: 30px;
    }
    .house-item-tit{
        position: relative;
        text-align: center;
    }
    .house-item-tit .tit-text{
        display: inline-block;
        background-color: #fff;
        padding: 0 20px;
        font-size: 26px;
        font-weight: normal;
    }
    .house-item-tit:after{
        content: '';
        position: absolute;
        width: 100%;
        height: 2px;
        left: 0;
        background-color: #ddd;
        z-index: -1;
        top: 16px;
    }
    .house-intro-r .house-intro-list{
        margin: 20px;
        color: #666;
    }
    .house-intro-r .house-intro-list li{
        padding: 5px 0;
    }
    .house-intro-r .house-intro-list li b{
        text-align: right;
        font-weight: normal;
        width: 120px;
        display: inline-block;
    }
    .house-intro-r .house-intro-list li span{
        margin-left: 15px;
        text-align: left;
    }

    .house-item-icon{
        margin: 30px -20px 0;
        display: flex;
        display: -webkit-flex;
        -webkit-flex-wrap: wrap;
        flex-wrap: wrap;
    }
    .house-item-icon li{
        padding: 15px 20px;
        width: 110px;
        text-align: center;
        color: #666;
    }
    .house-item-icon li .iconfont{
        font-size: 42px;
    }
    .house-item-icon li p{
        padding-top: 5px;
    }
    .house-item .house-project-intro{
        margin-top: 50px;
        padding: 20px;
        line-height: 32px;
        background-color: #f7f7f7;
    }
    .house-item .house-round{
        margin-top: 50px;
        line-height: 32px;
    }
    .map-guide{
        width: 100%;
        height: 600px;
        margin-top: 40px;
        text-align: center;
    }
    .fy-house-round{
        margin-top: 50px;
    }
</style>