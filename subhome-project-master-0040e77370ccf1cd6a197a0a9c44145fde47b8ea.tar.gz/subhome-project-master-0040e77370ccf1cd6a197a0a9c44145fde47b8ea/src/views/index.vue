<template>
   <div id="indexHome">
       <header class="s-header">
           <nav class="s-navbar">
               <div class="s-navbar-left pull-left">
                   <a href="index.html"><img src="@/assets/img/home_pic_navlogo.png" class="logo"></a>
               </div>
               <div class="s-navbar-right pull-right">
                   <ul class="nav-list index-nav-list">
                       <li class="current"><a>首页</a></li>
                       <li><a>赛领房源</a></li>
                       <li><a>社区活动</a></li>
                       <li><a>赛领动态</a></li>
                       <li><a>关于我们</a></li>
                   </ul>
               </div>
           </nav>
       </header>
       <section class="floor1 padding-100" id="top">
           <div class="slider-wrap">
               <ul class="slider-img">
                   <li><a href="#" class="spec-banner"></a></li>
               </ul>
               <!-- <ul class="flex-direction-nav" style="display: block">
                   <li><a class="flex-prev prev" href="javascript:;">Previous</a></li>
                   <li><a class="flex-next next" href="javascript:;">Next</a></li>
               </ul> -->
           </div>
       </section>

       <section class="floor floor2" id="indexHouseBox">
           <div class="floor-title">
               <h3>赛领<span></span>户型</h3>
               <p>打造别具一格的生活品位</p>
           </div>
           <div class="floor-body">
               <ul class="tab-list">
                   <li v-bind:class="{active: index == num}" v-on:click="toggle(value,index)" v-for="(value,index) in projectList"><span>{{value.name}}</span></li>
               </ul>
               <div class="flexslider" style="display: block">
                   <ul class="flex-direction-nav">
                       <li><a class="flex-prev prev" href="javascript:;">Previous</a></li>
                       <li><a class="flex-next next" href="javascript:;">Next</a></li>
                   </ul>
                       <div class="fy-slider">
                           <v-spin v-if="spinning">
                              <v-alert type="info" message="正在加载数据"
                                 description="请耐心等待"
                               ></v-alert>
                           </v-spin>
                           <ul class="fy-list">
                               <li class="imgBox" v-for="value in layoutList" @mouseenter="imgEnter" @mouseleave="imgLeave">
                                   <div class="slid-img"><img :src="value.coverImg" ></div>
                                   <div class="slid-fade">
                                       <div class="slid-mask" style="display: none"></div>
                                       <div class="slid-con">
                                           <p class="bot-font">{{value.layoutName}} . ￥{{value.rent}}/月</p>
                                           <router-link :to="`/detailHouse/${value.id}`" class="desc-btn" v-on:click="turnDetail(value.id)">查看详情</router-link>
                                       </div>
                                   </div>
                               </li>
                               <li class="imgBox" v-for="p in placeHoldImg" v-if="(placeHoldImg.length>0)">
                                   <div class="slid-img"><img id="p" src="@/assets/img/home_pic_housetype3.jpg"></div>
                               </li>
                           </ul>
                       </div>
               </div>
           </div>
       </section>

       <section class="floor floor3">
           <div class="floor-title">
               <h3>赛领<span></span>社区活动</h3>
               <p>认识不同的人，参加不一样的音乐酒会、生日party、经验分享、公益活动、社会活动</p>
           </div>
           <div class="floor-body">
               <ul class="hd-list">
                   <li class="imgBox transition">
                       <div class="hd-img"><img src="@/assets/img/home_pic_activity1.jpg"></div>
                       <div class="hd-tit">
                           <h3>Sail 美食趴</h3>
                           <p>明明可以靠颜值，偏偏却要拼手艺</p>
                       </div>
                   </li>
                   <li class="imgBox transition">
                       <div class="hd-img"><img src="@/assets/img/home_pic_activity2.jpg"></div>
                       <div class="hd-tit">
                           <h3>Sail 音乐会</h3>
                           <p>生命不止，梦想不灭，圆你音乐梦</p>
                       </div>
                   </li>
                   <li class="imgBox transition">
                       <div class="hd-img"><img src="@/assets/img/home_pic_activity3.jpg"></div>
                       <div class="hd-tit">
                           <h3>Sail 经验分享会</h3>
                           <p>美好的人总会遇见美好的事</p>
                       </div>
                   </li>
                   <li class="imgBox transition">
                       <div class="hd-img"><img src="@/assets/img/home_pic_activity4.jpg"></div>
                       <div class="hd-tit">
                           <h3>Sail 生日趴</h3>
                           <p>明明可以靠颜值，偏偏却要拼手艺</p>
                       </div>
                   </li>
               </ul>
           </div>
       </section>

       <section class="floor floor4" id="indexArticleBox">
           <div class="floor-title">
               <h3>赛领<span></span>动态</h3>
               <p>租房老司机带你探寻“不可告人”的秘密......</p>
           </div>
           <div class="floor-body">
               <p class="more"><router-link to="/listDynamic" class="pull-right"><span>查看更多...</span></router-link></p>
               <v-spin v-if="spinning">
                  <v-alert type="info" message="正在加载赛领动态数据"
                     description="请耐心等待"
                   ></v-alert>
               </v-spin>
               <ul class="dt-list">
                   <li class="imgBox" v-for="value in indexArticleList">
                       <router-link :to="`/detailDynamic/${value.id}`" v-on:click="turnDetail(value.id)">
                           <div class="dt-img"><img :src="value.coverImg" class="transition"></div>
                           <div class="dt-tit">
                               <h3>{{value.title}}</h3>
                           </div>
                       </router-link>
                   </li>
               </ul>
           </div>
       </section>

       <section class="floor floor5">
           <div class="floor-title">
               <h3>赛领<span></span>关于我们</h3>
               <p>About Us</p>
           </div>
           <div class="floor-body">
               <div class="sail-about">
                   <div class="imgBox"><img src="@/assets/img/home_pic_aboutus.jpg"></div>
                   <div class="sail-intro">
                       <p style="font-size: 16px;">
                           赛领公寓是贵阳市新微公租房试点项目，由贵阳市住房城乡建设局统筹指导，贵阳置业担保有限公司具体实施运营管理。
                           赛领公寓以国家加快培育和发展住房租赁市场，公共租赁住房转型升级为背景，是一个以集中 式长租为核心，以居住、服务、社交为主导功能的中高端公寓产品。
                       </p>
                       <p style="font-size: 16px;">
                           为进一步改善和提升公共租赁住房的品质，探索新时代公共租赁住房的创新发展道路，是贵阳市加快推进租赁市场发展品牌化、专业化、规模化、社区化的示范项目。

                       </p>
                       <p style="font-size: 16px;">
                           致力于打造最佳租住体验的标准化长租公寓品牌，项目实施统一管理“拎包入住”并配套公共娱乐区域、公共洗衣房等特色，
                           将带给租客新颖、丰富的租住体验，专门为高校毕业生、新就业职工、外地迁移到贵阳工作、新创业者等“贵漂”、“贵居”打造一个优质居住环境的集中式长租公寓。
                       </p>
                   </div>
               </div>
           </div>
       </section>

       <footer class="sail-footer">
           <div class="floor">
               <div class="foot-img">
                   <span class="pull-left"><img src="@/assets/img/home_pic_bottom.png" class="slogan"></span>
                   <span class="pull-right"><img src="@/assets/img/index_wechat.jpg" class="qcodeImg"><p class="qfont">扫码关注微信公众号</p></span>
               </div>
               <div class="foot-con">
                   <p>联系电话：400-120-2019</p>
                   <p>©2017 贵阳置业担保有限公司. All Rights Reserved.</p>
                   <p>黔ICP备18006675号-2</p>
               </div>
           </div>
       </footer>

       <section class="side-menu">
           <ul class="sideBox">
               <li><a href="#"><img src="@/assets/img/home_pic_navright.png"></a></li>
               <li>
                   <a href="#" class="mouseEject"><img src="@/assets/img/home_btn_wx.png"><p class="name">微信公众号</p></a>
                   <div class="hoverEject"><img src="@/assets/img/index_wechat.jpg"></div>
               </li>
                <li @click="openModal"><a href="#top"><img src="@/assets/img/预约看房.png"><p class="name">预约看房</p></a></li>
           </ul>
           <div class="container__top fix_color">
            <a href="#top">
              <p class="box__status">
                <img class='box__img' src="@/assets/img/回到顶部.png" alt="">
              </p>
              <p class='words__color'>
                <span >回到顶部</span>
              </p>
            </a>
           </div>
       </section>
       <addHouse :visible="visible" @hide="hideModal"></addHouse>
   </div>
</template>

<script>
  import { mapState } from 'vuex'
  import addHouse from '@/components/addHouse'
  import banner from '@/assets/img/home_pic_carouselfigure.jpg'
  export default {
    name: 'indexNice',
    components: {
      addHouse
    },
    computed: {
       ...mapState({
          indexArticleList: state => state.indexArticleList,
          projectList: state => state.projectList,
          layoutList: state => state.layoutList,
          placeHoldImg: state => state.placeHoldImg,
          spinning: state => state.spinning
       })
    },
    asyncData({store, route}) {
      let houseDetailId = route.params.id;
      let topList =  store.dispatch('topList', {
        id: houseDetailId,
        num: 4
      })
      let listRegion = store.dispatch('listRegion', true)
      return Promise.all([topList, listRegion])
    },
    mounted() {
      this.dataPromise.then(res => {
        //console.log('nice---setEFF')
        this.setEffects()
      })
      $(window).on("scroll", function(){
          var scrollTop = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop;
          scrollTop += 180;
          let floor = $(".floor5");
          if(!floor || floor.length === 0) return;
          //console.log('------------',scrollTop,  $(".floor5").offset().top)
          if(scrollTop >= floor.offset().top){
              $(".index-nav-list li").eq(4).addClass("current").siblings().removeClass("current");
          }else if(scrollTop >= $(".floor4").offset().top){
              $(".index-nav-list li").eq(3).addClass("current").siblings().removeClass("current");
          }else if(scrollTop >= $(".floor3").offset().top){
              $(".index-nav-list li").eq(2).addClass("current").siblings().removeClass("current");
          }else if(scrollTop >= $(".floor2").offset().top){
              $(".index-nav-list li").eq(1).addClass("current").siblings().removeClass("current");
          }else{
              $(".index-nav-list li").eq(0).addClass("current").siblings().removeClass("current");
          }
      });

      $('.nav-list').find('li').click(function () {
          $(this).addClass('current').siblings().removeClass('current');
          var obj = ".floor" + ($(this).index() + 1);
          $("html, body").animate(
              {
                  scrollTop: $(obj).offset().top - 180
              },
              200
          );
      });

      // wechat
      $('.mouseEject').hover(function () {
          $(this).next('.hoverEject').toggle(100);
      });

      // hd-list
      $('.hd-list').find('.imgBox').hover(function () {
          $(this).toggleClass('on');
      });

      $(function () {
          //index slider
          $(".slider-wrap").slide({
              mainCell:".slider-img",
              effect: 'fold',
              autoPlay:true
          });

      });
    },
    data: function() {
      return {
         name: 'sailHome',
         banner: banner,
         visible: false,
         num:0,
         regionNum:2,
      };
    },
    methods: {
      hideModal() {
        this.visible = false;
      },
      openModal(event) {
        event.preventDefault()
        this.visible = true;
      },
      imgEnter:function (event) {
        //console.log('event', event.target)
          $(event.target).find('.slid-mask').fadeIn(200);
          $(event.target).find('.slid-con').css('bottom','50%');
          // $('.imgBox').mouseenter(function () {
          //   //console.log('enter')
          // });
      },
      imgLeave:function (event) {
          $(event.target).find('.slid-mask').fadeOut(200);
          $(event.target).find('.slid-con').css('bottom','-10px');
          // $('.imgBox').mouseleave(function () {
          // });
      },
      turnDetail:function (key) {
          console.log('key',key)
          sessionStorage.setItem('house-detail-id',key);
      },
      toggle:function (value,index) {
          var id = value.id;
          this.num = index;
          $(this).addClass('active').siblings().removeClass('active');
          this.$store.dispatch('getLayoutListByRegionId', {
            regionId: id
          }).then(res => {
            this.setEffects()
          })
      },
      setEffects:function () {
        if($(".flexslider").slide){
           $(".flexslider").slide({
                mainCell:".fy-list",
                scroll:"1",
                autoPage:true,
                effect:"left",
                autoPlay:false,
                vis:4
           }); 
        }
      }
    }
  }
</script>
<style scoped lang='less'>
    .more{
        margin-bottom: 20px;
        display: inline-block;
        width: 100%;      
    }
    .more span {
       color: #007739;
       font-size: 16px;
    }
    .more span:hover{
        color: #019448;
    }
    .spec-banner {
      background: url('../assets/img/home_pic_carouselfigure.jpg') center center no-repeat
    }
    .side-menu {

      .container__top{
        margin-top: 10px;
        padding-top: 10px;
        height: 60px;
        width: 80px;       
      }
      .words__color{
        color:#fff;
        font-size: 11px;       
        text-align: center;
      }
      .words__color:hover{
        color:green;
        cursor: pointer;
      }
      .box__status{
        text-align: center;
      }
      .box__img{
        opacity: 0.8;
      }
      .box__main{
        cursor: pointer;
        padding-top: 14px;
      }
      .fix_color{
        background: rgba(0,0,0,.5);
        border-radius: 5px;
      }
    }
</style>